Group name: DBMonsters
Group member:
Huy Vu
MD Aeinul Islam
Yuan Ye

Note:
	Because we use flask template for the project, the flask folder size is too big (about 31MB), so we cannot put it into the zip file due to the size limit (2MB). Therefore, we only turn in everything we need except for the flask.
	If you want to test it, you can get the complete project from github: https://github.com/vuhuy1101/DBM.git
	Or you can install the flask library and flask-mysqldb with the following commands:
	
	
	Install the virtualenv for flask:
	virtualenv flask
	cd flask/
	source bin/activate
	
	Now, you can run "python app.py" to run the web application
	
	
	
	